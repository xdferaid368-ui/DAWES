from django.apps import AppConfig


class TiendaConfig(AppConfig):
    name = 'tienda'
